import cv2
import mediapipe as mp
import tkinter as tk
import time
import math
from collections import deque
from PIL import Image, ImageTk

# ====== CONFIG ======
video_path = r"assets/kicaw.mp4"
cooldown = 1.5  # seconds between gesture triggers

# ====== MEDIAPIPE ======
mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils
mp_draw_styles = mp.solutions.drawing_styles

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    model_complexity=0,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.5
)

# ====== FINGER STATE DETECTION ======
def is_thumb_extended(hand_landmarks, handedness):
    tip = hand_landmarks.landmark[4]
    ip  = hand_landmarks.landmark[3]
    mcp = hand_landmarks.landmark[2]
    gap = abs(tip.x - ip.x)
    min_gap = 0.02

    # Frame is flipped with cv2.flip(frame, 1), so MediaPipe's x-axis is
    # mirrored — swap the direction check for each hand label.
    if handedness == "Right":
        return tip.x < ip.x and ip.x < mcp.x and gap > min_gap
    return tip.x > ip.x and ip.x > mcp.x and gap > min_gap


def is_finger_extended(hand_landmarks, tip_idx, pip_idx):
    tip = hand_landmarks.landmark[tip_idx]
    pip = hand_landmarks.landmark[pip_idx]
    mcp = hand_landmarks.landmark[tip_idx - 3]
    return tip.y < pip.y and tip.y < mcp.y


def get_finger_states(hand_landmarks, handedness="Right"):
    return [
        1 if is_thumb_extended(hand_landmarks, handedness) else 0,
        1 if is_finger_extended(hand_landmarks, 8, 6) else 0,
        1 if is_finger_extended(hand_landmarks, 12, 10) else 0,
        1 if is_finger_extended(hand_landmarks, 16, 14) else 0,
        1 if is_finger_extended(hand_landmarks, 20, 18) else 0,
    ]


def count_fingers(states):
    return sum(states)


def is_ily_sign(states):
    return states[0] == 1 and states[1] == 1 and states[2] == 0 and states[3] == 0 and states[4] == 1





# ====== ILY TRACKER ======
class ILYTracker:
    def __init__(self, hold_frames=10):
        self.hold_frames = hold_frames
        self._count = 0
        self._triggered = False

    def update(self, finger_states):
        if is_ily_sign(finger_states):
            self._count += 1
        else:
            self._count = 0
            self._triggered = False

        if self._count >= self.hold_frames and not self._triggered:
            self._triggered = True
            return True
        return False

    def reset(self):
        self._count = 0
        self._triggered = False


# ====== EASTER EGG ======
_EGG_MESSAGES = [
    ("KICAWWW \u2728", "#ff6b9d")
]
_egg_index = 0


def draw_romantic_overlay(frame, progress):
    h, w = frame.shape[:2]
    overlay = frame.copy()
    alpha = min(progress * 2.5, 0.4)
    cv2.rectangle(overlay, (0, 0), (w, h), (180, 100, 180), -1)
    cv2.addWeighted(overlay, alpha * 0.22, frame, 1 - alpha * 0.22, 0, frame)
    heart_positions = [
        (int(w * 0.12), int(h * 0.18)),
        (int(w * 0.82), int(h * 0.22)),
        (int(w * 0.50), int(h * 0.10)),
        (int(w * 0.25), int(h * 0.78)),
        (int(w * 0.75), int(h * 0.82)),
    ]
    pulse = int(14 + 4 * math.sin(progress * math.pi * 8))
    for hx, hy in heart_positions:
        cv2.putText(frame, chr(0x2665), (hx, hy),
                    cv2.FONT_HERSHEY_SIMPLEX, pulse / 18,
                    (80, 80, 210), 1, cv2.LINE_AA)
    return frame


# ====== MAIN GUI ======
class GestureVideoGUI:
    def __init__(self, root):
        self.root = root
        root.title("Hand Gesture Video Player")
        root.configure(bg="#141414")
        root.geometry("980x700")
        root.resizable(False, False)

        self.camera = self.open_camera()
        if self.camera is None:
            self.show_error("Camera could not be opened.\nMake sure no other app is using it.")
            return

        self.video  = None
        self.playing = False
        self.last_trigger = 0
        self.current_fingers = 0
        self.easter_egg_until = 0.0
        self.easter_egg_start = 0.0
        self.easter_egg_duration = 4.5

        self.ily_tracker = ILYTracker()
        self._finger_buffer = deque(maxlen=5)
        self._hint_until = 0.0

        self.build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.bind("<q>", self.handle_quit_key)
        self.root.bind("<Q>", self.handle_quit_key)
        self.root.after(30, self.update_frame)

    # ------------------------------------------------------------------ UI --
    def build_ui(self):
        header = tk.Frame(self.root, bg="#141414")
        header.pack(fill="x")

        tk.Label(header, text="\u270b  Hand Gesture Player",
                 fg="#f0f0f0", bg="#141414",
                 font=("Segoe UI", 20, "bold")).pack(side="left", padx=20, pady=14)

        self.status_badge = tk.Label(header, text="\u25cf IDLE",
                                     fg="#888888", bg="#141414",
                                     font=("Segoe UI", 12, "bold"))
        self.status_badge.pack(side="right", padx=20, pady=14)

        panel = tk.Frame(self.root, bg="#1c1c1c")
        panel.pack(fill="both", expand=True, padx=14)

        # Camera pane
        cam_outer = tk.Frame(panel, bg="#2a2a2a")
        cam_outer.place(x=10, y=10, width=468, height=425)
        tk.Label(cam_outer, text="Camera", fg="#9e9e9e", bg="#2a2a2a",
                 font=("Segoe UI", 10)).place(x=8, y=4)
        self.cam_label = tk.Label(cam_outer, bg="#000000")
        self.cam_label.place(x=4, y=24, width=460, height=392)

        self.gesture_hint_var = tk.StringVar(value="")
        tk.Label(cam_outer, textvariable=self.gesture_hint_var,
                 fg="#ffdd88", bg="#2a2a2a",
                 font=("Segoe UI", 11, "bold")).place(x=8, y=400)

        # Video pane
        vid_outer = tk.Frame(panel, bg="#2a2a2a")
        vid_outer.place(x=492, y=10, width=468, height=425)
        tk.Label(vid_outer, text="Video Player", fg="#9e9e9e", bg="#2a2a2a",
                 font=("Segoe UI", 10)).place(x=8, y=4)
        self.video_label = tk.Label(vid_outer, text="Waiting for gesture\u2026",
                                    fg="#555555", bg="#0a0a0a",
                                    font=("Segoe UI", 12))
        self.video_label.place(x=4, y=24, width=460, height=392)

        self.egg_text_var = tk.StringVar(value="")
        self.egg_text_label = tk.Label(vid_outer, textvariable=self.egg_text_var,
                                       fg="#ff85c2", bg="#0a0a0a",
                                       font=("Segoe UI", 16, "bold"),
                                       justify="center", wraplength=420)
        self.egg_text_label.place(x=4, y=156, width=460, height=120)
        self.egg_text_label.lower()

        # Status bar
        status_bar = tk.Frame(self.root, bg="#111111", height=105)
        status_bar.pack(fill="x", padx=14, pady=(8, 10))
        status_bar.pack_propagate(False)

        left = tk.Frame(status_bar, bg="#111111")
        left.pack(side="left", fill="both", expand=True, padx=14, pady=8)

        self.detail_var = tk.StringVar(value="Camera: searching\u2026  |  Hand: \u2013  |  Fingers: \u2013  |  State: Idle")
        tk.Label(left, textvariable=self.detail_var, fg="#aaaaaa", bg="#111111",
                 font=("Segoe UI", 11), anchor="w").pack(fill="x")

        self.sub_var = tk.StringVar(value="Show 2 fingers to play  \u2022  Show 1 finger to stop")
        tk.Label(left, textvariable=self.sub_var, fg="#555555", bg="#111111",
                 font=("Segoe UI", 10), anchor="w").pack(fill="x", pady=(4, 0))

        right = tk.Frame(status_bar, bg="#111111")
        right.pack(side="right", padx=14, pady=8)
        tk.Button(right, text="Quit", command=self.on_close,
                  fg="#ffffff", bg="#c0392b", activebackground="#e74c3c",
                  font=("Segoe UI", 11, "bold"), bd=0, padx=20, pady=8,
                  cursor="hand2", relief="flat").pack()

    def _set_badge(self, text, color):
        self.status_badge.configure(text=text, fg=color)

    def show_error(self, message):
        dlg = tk.Toplevel(self.root)
        dlg.title("Error")
        dlg.configure(bg="#2e2e2e")
        dlg.geometry("360x160")
        tk.Label(dlg, text=message, fg="#ffffff", bg="#2e2e2e",
                 font=("Segoe UI", 12), wraplength=320, justify="center").pack(padx=18, pady=18)
        tk.Button(dlg, text="Close", command=dlg.destroy,
                  fg="#ffffff", bg="#555555", bd=0, padx=14, pady=8).pack(pady=(0, 14))

    # ---------------------------------------------------------------- Camera
    def open_camera(self):
        for backend in [cv2.CAP_DSHOW, cv2.CAP_MSMF, cv2.CAP_ANY]:
            cap = cv2.VideoCapture(1, backend)
            if cap.isOpened():
                ret, frame = cap.read()
                if ret and frame is not None:
                    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                    cap.set(cv2.CAP_PROP_FPS, 30)
                    return cap
                cap.release()
        return None

    def cv2_to_tk(self, frame):
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        return ImageTk.PhotoImage(image=Image.fromarray(frame))

    # ---------------------------------------------------------- Update loop
    def update_frame(self):
        if self.camera is None:
            return

        ret, frame = self.camera.read()
        if not ret or frame is None:
            self._set_badge("\u25cf ERROR", "#e74c3c")
            self.root.after(100, self.update_frame)
            return

        frame  = cv2.flip(frame, 1)
        rgb    = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb)

        now = time.time()
        egg_active    = now < self.easter_egg_until
        finger_states = [0, 0, 0, 0, 0]

        if result.multi_hand_landmarks and result.multi_handedness:
            for hand_lm, handedness_info in zip(result.multi_hand_landmarks, result.multi_handedness):
                label         = handedness_info.classification[0].label
                finger_states = get_finger_states(hand_lm, label)
                finger_count  = count_fingers(finger_states)

                self._finger_buffer.append(finger_count)
                smooth_count = round(sum(self._finger_buffer) / len(self._finger_buffer))
                self.current_fingers = smooth_count

                # Draw landmarks
                mp_draw.draw_landmarks(
                    frame, hand_lm, mp_hands.HAND_CONNECTIONS,
                    mp_draw_styles.get_default_hand_landmarks_style(),
                    mp_draw_styles.get_default_hand_connections_style()
                )

                # Bounding box
                h, w, _ = frame.shape
                xs = [int(lm.x * w) for lm in hand_lm.landmark]
                ys = [int(lm.y * h) for lm in hand_lm.landmark]
                x1, y1 = max(min(xs) - 16, 0),     max(min(ys) - 16, 0)
                x2, y2 = min(max(xs) + 16, w - 1),  min(max(ys) + 16, h - 1)

                box_color = (100, 220, 100) if self.playing else (100, 160, 255)
                if egg_active:
                    box_color = (180, 100, 220)
                cv2.rectangle(frame, (x1, y1), (x2, y2), box_color, 2)
                cv2.rectangle(frame, (x1, y1 - 28), (x1 + 40, y1), box_color, -1)
                cv2.putText(frame, str(smooth_count), (x1 + 6, y1 - 6),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 0), 2, cv2.LINE_AA)

                # Gesture logic (ILY > 2-finger play > 1-finger stop)
                if now - self.last_trigger > cooldown:
                    if self.ily_tracker.update(finger_states):
                        self.trigger_easter_egg()
                        self.last_trigger = now

                    elif finger_count == 2 and not self.playing:
                        self._show_hint("2 fingers  \u25ba  play")
                        if self.start_video(video_path):
                            self.playing = True
                            self._set_badge("\u25cf PLAYING", "#2ecc71")
                        self.last_trigger = now

                    elif finger_count == 1 and self.playing:
                        self._show_hint("1 finger  \u25a0  stop")
                        self.stop_video()
                        self.playing = False
                        self._set_badge("\u25cf STOPPED", "#e67e22")
                        self.last_trigger = now

                break  # first hand only
        else:
            self._finger_buffer.clear()
            self.current_fingers = 0

        # Easter egg camera overlay
        if egg_active:
            progress = (now - self.easter_egg_start) / self.easter_egg_duration
            frame = draw_romantic_overlay(frame, progress)

        # Camera display
        display_frame = cv2.resize(frame, (460, 392))
        cam_img = self.cv2_to_tk(display_frame)
        self.cam_label.configure(image=cam_img)
        self.cam_label.image = cam_img

        # Status bar
        hand_str  = "detected" if result.multi_hand_landmarks else "not found"
        state_str = "Playing" if self.playing else ("Easter egg \u2728" if egg_active else "Idle")
        self.detail_var.set(
            f"Camera: active  |  Hand: {hand_str}  |  Fingers: {self.current_fingers}  |  State: {state_str}"
        )
        if not self.playing and not egg_active:
            self._set_badge("\u25cf IDLE", "#888888")

        # Hint fade
        if now > self._hint_until:
            self.gesture_hint_var.set("")

        # Video playback
        if self.playing and self.video is not None:
            ret_v, vframe = self.video.read()
            if not ret_v or vframe is None:
                self.stop_video()
                self.playing = False
                self._set_badge("\u25cf ENDED", "#888888")
            else:
                vid_img = self.cv2_to_tk(cv2.resize(vframe, (460, 392)))
                self.video_label.configure(image=vid_img, text="")
                self.video_label.image = vid_img
                self.egg_text_label.lower()
        elif egg_active:
            self.video_label.configure(image="", text="", bg="#0a0a0a")
            self.video_label.image = None
            self.egg_text_label.lift()
        else:
            self.video_label.configure(image="", text="Waiting for gesture\u2026",
                                       fg="#555555", bg="#0a0a0a")
            self.video_label.image = None
            self.egg_text_label.lower()

        self.root.after(30, self.update_frame)

    def _show_hint(self, text, duration=2.0):
        self.gesture_hint_var.set(text)
        self._hint_until = time.time() + duration

    # -------------------------------------------------------- Video controls
    def start_video(self, path):
        if self.video is not None:
            self.video.release()
        self.video = cv2.VideoCapture(path)
        if not self.video.isOpened():
            self._set_badge("\u25cf FILE ERROR", "#e74c3c")
            self.video = None
            return False
        return True

    def stop_video(self):
        if self.video is not None:
            self.video.release()
            self.video = None
        self.video_label.configure(text="Waiting for gesture\u2026",
                                   fg="#555555", bg="#0a0a0a", image="")
        self.video_label.image = None

    # --------------------------------------------------------- Easter egg
    def trigger_easter_egg(self):
        global _egg_index
        if self.playing:
            self.stop_video()
            self.playing = False

        self.easter_egg_start = time.time()
        self.easter_egg_until = self.easter_egg_start + self.easter_egg_duration

        msg, color = _EGG_MESSAGES[_egg_index % len(_EGG_MESSAGES)]
        _egg_index += 1

        self.egg_text_var.set(msg)
        self.egg_text_label.configure(fg=color)
        self._set_badge("\u2756 secret", "#ff85c2")

    # ------------------------------------------------------------ Lifecycle
    def on_close(self):
        if self.video is not None:
            self.video.release()
        if self.camera is not None:
            self.camera.release()
        cv2.destroyAllWindows()
        self.root.quit()

    def handle_quit_key(self, event):
        self.on_close()


if __name__ == "__main__":
    root = tk.Tk()
    app = GestureVideoGUI(root)
    root.mainloop()
